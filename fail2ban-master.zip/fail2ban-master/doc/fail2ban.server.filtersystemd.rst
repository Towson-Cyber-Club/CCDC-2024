fail2ban.server.filtersystemd module
====================================

.. automodule:: fail2ban.server.filtersystemd
    :members:
    :undoc-members:
    :show-inheritance:
