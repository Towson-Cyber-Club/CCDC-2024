pcap_t *pcap_netmap_create(const char *, char *, int *);
int pcap_netmap_findalldevs(pcap_if_list_t *devlistp, char *errbuf);
